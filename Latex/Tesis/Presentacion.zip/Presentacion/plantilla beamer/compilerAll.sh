#!/bin/bash

cd myfolder; for i in *.tex; do pdflatex $i;done